<?php
// devolucion.php
require_once 'conexion.php';

// Verificar si se recibió el ID de reserva
if (isset($_POST['id_reserva'])) {
    $id_reserva = $_POST['id_reserva'];
    
    try {
        // Iniciar transacción
        $pdo->beginTransaction();
        
        // 1. Obtener información de la reserva
        $sql_reserva = "SELECT id_libro, id_usuario FROM reservas WHERE id = ? AND estado = 'activo'";
        $stmt_reserva = $pdo->prepare($sql_reserva);
        $stmt_reserva->execute([$id_reserva]);
        $reserva = $stmt_reserva->fetch(PDO::FETCH_ASSOC);
        
        if (!$reserva) {
            throw new Exception("Reserva no encontrada o ya devuelta");
        }
        
        $id_libro = $reserva['id_libro'];
        $id_usuario = $reserva['id_usuario'];
        
        // 2. Actualizar el estado del libro a disponible
        $sql_libro = "UPDATE libros SET estado = 'disponible' WHERE id = ?";
        $stmt_libro = $pdo->prepare($sql_libro);
        $stmt_libro->execute([$id_libro]);
        
        // 3. Marcar la reserva como completada (en lugar de eliminarla)
        $sql_update_reserva = "UPDATE reservas SET estado = 'completado', fecha_devolucion = NOW() WHERE id = ?";
        $stmt_update = $pdo->prepare($sql_update_reserva);
        $stmt_update->execute([$id_reserva]);
        
        // Confirmar transacción
        $pdo->commit();
        
        // Respuesta exitosa
        echo json_encode([
            'success' => true,
            'message' => 'Libro devuelto exitosamente',
            'id_libro' => $id_libro,
            'id_usuario' => $id_usuario
        ]);
        
    } catch (Exception $e) {
        // Revertir transacción en caso de error
        $pdo->rollBack();
        
        // Respuesta de error
        echo json_encode([
            'success' => false,
            'message' => 'Error al devolver el libro: ' . $e->getMessage()
        ]);
    }
} else {
    // Si no se recibió el ID de reserva
    echo json_encode([
        'success' => false,
        'message' => 'ID de reserva no proporcionado'
    ]);
}
?>