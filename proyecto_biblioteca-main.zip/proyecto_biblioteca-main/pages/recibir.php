<?php
require '../system/session.php';
require '../layout/header.php';
?>



<?php
require '../layout/footer.php';